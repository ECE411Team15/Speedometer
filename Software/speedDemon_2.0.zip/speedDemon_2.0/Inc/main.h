/**
  ******************************************************************************
  * File Name          : main.hpp
  * Description        : This file contains the common defines of the application
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H
  /* Includes ------------------------------------------------------------------*/

/* Includes ------------------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/

#define UnusePin_Pin GPIO_PIN_13
#define UnusePin_GPIO_Port GPIOC
#define UnusePinC14_Pin GPIO_PIN_14
#define UnusePinC14_GPIO_Port GPIOC
#define UnusePinC15_Pin GPIO_PIN_15
#define UnusePinC15_GPIO_Port GPIOC
#define UnusePinA0_Pin GPIO_PIN_0
#define UnusePinA0_GPIO_Port GPIOA
#define UnusePinA1_Pin GPIO_PIN_1
#define UnusePinA1_GPIO_Port GPIOA
#define UnusePinA2_Pin GPIO_PIN_2
#define UnusePinA2_GPIO_Port GPIOA
#define RS_Pin GPIO_PIN_3
#define RS_GPIO_Port GPIOA
#define RW_Pin GPIO_PIN_4
#define RW_GPIO_Port GPIOA
#define EN_Pin GPIO_PIN_5
#define EN_GPIO_Port GPIOA
#define D0_Pin GPIO_PIN_6
#define D0_GPIO_Port GPIOA
#define D1_Pin GPIO_PIN_7
#define D1_GPIO_Port GPIOA
#define D2_Pin GPIO_PIN_0
#define D2_GPIO_Port GPIOB
#define D3_Pin GPIO_PIN_1
#define D3_GPIO_Port GPIOB
#define D4_Pin GPIO_PIN_2
#define D4_GPIO_Port GPIOB
#define D5_Pin GPIO_PIN_10
#define D5_GPIO_Port GPIOB
#define D6_Pin GPIO_PIN_11
#define D6_GPIO_Port GPIOB
#define D7_Pin GPIO_PIN_12
#define D7_GPIO_Port GPIOB
#define UnusePinB13_Pin GPIO_PIN_13
#define UnusePinB13_GPIO_Port GPIOB
#define UnusePinB14_Pin GPIO_PIN_14
#define UnusePinB14_GPIO_Port GPIOB
#define UnusePinB15_Pin GPIO_PIN_15
#define UnusePinB15_GPIO_Port GPIOB
#define Sensor_Pin GPIO_PIN_8
#define Sensor_GPIO_Port GPIOA
#define UnusePinA9_Pin GPIO_PIN_9
#define UnusePinA9_GPIO_Port GPIOA
#define UnusePinA10_Pin GPIO_PIN_10
#define UnusePinA10_GPIO_Port GPIOA
#define UnusePinA11_Pin GPIO_PIN_11
#define UnusePinA11_GPIO_Port GPIOA
#define UnusePinA12_Pin GPIO_PIN_12
#define UnusePinA12_GPIO_Port GPIOA
#define UnusePinA15_Pin GPIO_PIN_15
#define UnusePinA15_GPIO_Port GPIOA
#define Up_Pin GPIO_PIN_3
#define Up_GPIO_Port GPIOB
#define Up_EXTI_IRQn EXTI2_3_IRQn
#define Down_Pin GPIO_PIN_4
#define Down_GPIO_Port GPIOB
#define Down_EXTI_IRQn EXTI4_15_IRQn
#define Right_Pin GPIO_PIN_5
#define Right_GPIO_Port GPIOB
#define Right_EXTI_IRQn EXTI4_15_IRQn
#define Select_Pin GPIO_PIN_6
#define Select_GPIO_Port GPIOB
#define Select_EXTI_IRQn EXTI4_15_IRQn
#define Left_Pin GPIO_PIN_7
#define Left_GPIO_Port GPIOB
#define Left_EXTI_IRQn EXTI4_15_IRQn
#define UnusePinB8_Pin GPIO_PIN_8
#define UnusePinB8_GPIO_Port GPIOB
#define UnusePinB9_Pin GPIO_PIN_9
#define UnusePinB9_GPIO_Port GPIOB

/* ########################## Assert Selection ############################## */
/**
  * @brief Uncomment the line below to expanse the "assert_param" macro in the 
  *        HAL drivers code
  */
/* #define USE_FULL_ASSERT    1U */

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
 extern "C" {
#endif
void _Error_Handler(char *, int);

#define Error_Handler() _Error_Handler(__FILE__, __LINE__)
#ifdef __cplusplus
}
#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

#endif /* __MAIN_H */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
