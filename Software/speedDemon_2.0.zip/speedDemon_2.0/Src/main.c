/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"

/* USER CODE BEGIN Includes */
#include "string.h"
#include "functions.c"

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

// Function to be called on input capture event. Will get period between input captures.
// Has no return type. 
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim -> Instance == TIM1)															// On input capture event:
	{
		if(revolution < refresh_rate)														// Increase number of revolutions until refresh rate has been reached.
			revolution++;
		if(revolution == refresh_rate + 1 && refresh_flag == 1)	// Set refresh to a larger value once we start picking up speed. 
			refresh_rate = 8;
		
		period = __HAL_TIM_GET_COMPARE(&htim1,TIM_CHANNEL_1);		// Get period of input captures.
		
		__HAL_TIM_SET_COUNTER(&htim1,0);												// Reset counter back to zero. 
	}
}

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */
	uint16_t timer_count = 0;			// Stores count from timer.
	double numerator = 0;					// Stores result of numerator for speed calculation.
	int speed = 1;								// Stores calculated speed result.
	_Bool initial_clear = 0;			// Used for initially clearing the display in speed mode.
	int zero_refresh = 1250;			// Variable that holds threshold for setting the speed to zero.
	int previous_speed = 0;				// Value to hold previously calculated speed.
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();

  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
		 
	
	HAL_TIM_Base_Start(&htim2);									// Starting base timer. 
	HAL_TIM_IC_Start_IT(&htim1,TIM_CHANNEL_1);	// Starting input capture in interrupt mode.
	

	OLED_initialize();	// Calling function to display initial information

	while(1)	
  {
		timer_count = __HAL_TIM_GET_COUNTER(&htim1);								// Get count time from counter.
		

		if(previous_speed >= 10)		// Checking what the value of the previous speed was.
			disp_update_flag_1 = 1;			// Set flag to logic high if condition true.
		else
			disp_update_flag_1 = 0;
		if(previous_speed > 100)		// Setting flag if speed is above 100.
			disp_update_flag_2 = 1;		
		else
			disp_update_flag_2 = 0;
		if(previous_speed > 1000)		// Setting flag if speed is above 1000.
			disp_update_flag_3 = 1;		
		else
			disp_update_flag_3 = 0;
		
		if(go_flag == 1 && conversion_mode > 0)				// If statement used to prompt user on initial selection of speed mode.
		{
			HAL_TIM_IC_Start_IT(&htim1,TIM_CHANNEL_1);	// Starting input capture in interrupt mode.
			
			OLED_sendCommand(0x01);			// Clearing OLED.
			OLED_sendCommand(0x80);			// Setting cursor position.
			if(conversion_mode == 1)		// Display appropriate speed units.
				OLED_sendString("km/h");
			else
				OLED_sendString("mph");
			
			HAL_Delay(1250);						// Give delay so user can see the option they have selected.				
			OLED_sendCommand(0x01);	
			OLED_sendCommand(0x80);			
			OLED_sendString("Go!");			// User may now begin to ride the bike.		
			go_flag = 0;
			initial_clear = 1;
		}
		if(conversion_mode == 1 && revolution == refresh_rate)
		{
			HAL_NVIC_DisableIRQ(EXTI2_3_IRQn);					// Turning off mode functionality while calculating speed. FOR SAFETY
			HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);					// Turning off mode functionality while calculating speed. FOR SAFETY

			if(initial_clear == 1)											// If statement is used to clear "Go!" for initial use.
			{	
				OLED_sendCommand(0x1);										// Clearing OLED.
				initial_clear = 0;												// Reset flag.
			}
			
			numerator = 72 * Radius * 3.1459;
			
			speed = 0;																		// Set speed to zero to reset value.
			speed = calculate_speed(period,numerator);		// Call function to calculate speed.
			previous_speed = speed;												// Setting speed to variable to keep track of previous speed.
			send_speed(speed);														// Call function to send speed to OLED.
			OLED_sendCommand(0xC0);												// Setting cursor position.
			OLED_sendString("km/h");											// Speed unit to be calculated.
		

			period = 0;																		// Resetting variables.
			zero_flag = 1;																
			revolution = 1;
			go_flag = 0;;																			
		}
		else if(conversion_mode == 2 && revolution == refresh_rate)
		{
			HAL_NVIC_DisableIRQ(EXTI2_3_IRQn);						// Turning off mode functionality while calculating speed. FOR SAFETY
			HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);						// Turning off mode functionality while calculating speed. FOR SAFETY

			if(initial_clear == 1)												// If statement is used to clear "Go!" for initial use.
			{
				OLED_sendCommand(0x1);											// Clearing OLED.
				initial_clear = 0;													// Reset flag.
			}
			numerator = 72 * Radius * 3.1459*.621371;
			speed = 0;																		// Set speed to zero to reset value.
			speed = calculate_speed(period,numerator);		// Call function to calculate speed.
			previous_speed = speed;												// Setting speed to variable to keep track of previous speed.
			send_speed(speed);														// Call function to send speed to OLED.
			
			
			OLED_sendCommand(0xC0);												// Setting cursor position.
			OLED_sendString("mph");
			
			period = 0;																		// Resetting variables.
			zero_flag = 1;
			revolution = 1;		
			go_flag = 0;
		}
		else if(timer_count > zero_refresh && zero_flag == 1)
		{
			
			OLED_sendCommand(0x1);					// Clearing OLED.
			int to_disp = 0;								// Set value to display to zero.
			send_speed(to_disp);						// Send zero speed to OLED.
			OLED_sendCommand(0xC0);					// Setting cursor position to second line.
			if(conversion_mode == 1)				// Display the correct speed unit.
				OLED_sendString("km/h");
			else
				OLED_sendString("mph");
			
			HAL_NVIC_EnableIRQ(EXTI2_3_IRQn);		// Enable interrupts. Allows user to begin changing modes ONCE STOPPED.
			HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);	
			
			zero_flag = 0;					// Resetting variables.
			timer_count =0;
			refresh_flag = 0;
			speed = 0;
				
		}
		
		if(zero_flag == 0)														// User must be stopped for following functions to execute.
		{
			if(conversion_mode == 0)										// If we aren't in speed conversion mode...
			{
				HAL_TIM_IC_Stop_IT(&htim1,TIM_CHANNEL_1);	// Stop input capture in interrupt mode.
			}
			
			Flag_Check();			// Function to check button flags.
			Mode_Check();			// Function to select mode.
		}
		
		if(Radius > 20)					// If the radius is greater than 20 cm, update threshold for setting speed to zero.
			zero_refresh = 2000;
		else
			zero_refresh = 1250;
		
	}	
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* TIM1 init function */
static void MX_TIM1_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 8000;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 60000;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, RS_Pin|RW_Pin|EN_Pin|D0_Pin 
                          |D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, D2_Pin|D3_Pin|D4_Pin|D5_Pin 
                          |D6_Pin|D7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : UnusePin_Pin UnusePinC14_Pin UnusePinC15_Pin */
  GPIO_InitStruct.Pin = UnusePin_Pin|UnusePinC14_Pin|UnusePinC15_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : UnusePinA0_Pin UnusePinA1_Pin UnusePinA2_Pin UnusePinA9_Pin 
                           UnusePinA10_Pin UnusePinA11_Pin UnusePinA12_Pin UnusePinA15_Pin */
  GPIO_InitStruct.Pin = UnusePinA0_Pin|UnusePinA1_Pin|UnusePinA2_Pin|UnusePinA9_Pin 
                          |UnusePinA10_Pin|UnusePinA11_Pin|UnusePinA12_Pin|UnusePinA15_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : RS_Pin RW_Pin EN_Pin D0_Pin 
                           D1_Pin */
  GPIO_InitStruct.Pin = RS_Pin|RW_Pin|EN_Pin|D0_Pin 
                          |D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : D2_Pin D3_Pin D4_Pin D5_Pin 
                           D6_Pin D7_Pin */
  GPIO_InitStruct.Pin = D2_Pin|D3_Pin|D4_Pin|D5_Pin 
                          |D6_Pin|D7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : UnusePinB13_Pin UnusePinB14_Pin UnusePinB15_Pin UnusePinB8_Pin 
                           UnusePinB9_Pin */
  GPIO_InitStruct.Pin = UnusePinB13_Pin|UnusePinB14_Pin|UnusePinB15_Pin|UnusePinB8_Pin 
                          |UnusePinB9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : Up_Pin Down_Pin Right_Pin Select_Pin 
                           Left_Pin */
  GPIO_InitStruct.Pin = Up_Pin|Down_Pin|Right_Pin|Select_Pin 
                          |Left_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
