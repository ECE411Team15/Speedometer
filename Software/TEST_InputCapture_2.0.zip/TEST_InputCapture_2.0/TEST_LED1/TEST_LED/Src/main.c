/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"
#include "string.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM1_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
#define clear_display = 0x1					// Clears display.
#define return_home = 0x2						// Returns display to home.
#define shift_curs_left = 0x4				// Shifts cursor left.
#define shift_curs_right = 0x6			// Shifts cursor right.
#define shift_disp_right = 0x5			// Shifts display right.
#define shift_disp_left = 0x7				// Shift display left.
#define display_off = 0x8						// Turn off display.
#define disp_on_curs_off = 0xC			// Turn on display, cursor off.
#define disp_on_curs_on = 0xE				// Turn on display, cursor on.
#define disp_on_blink = 0xF					// Turn on display, cursor blink.
#define move_curs_left = 0x10				// Move cursor left.
#define move_curs_right = 0x1C			// Move cursor right.
#define curs_reset_first = 0x80			// Reset/force cursor to first line.
#define curs_reset_second = 0xC0		// Reset/force cursor to second line.

// ---------------------------------------------------------------
#define command_byte = 0x38					// COMMAND WORD FOR 8 BIT MODE
// ---------------------------------------------------------------
																																					// **ALL FUNCTION ARGUMENTS PASSED BY VALUE**
void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state);	// Function prototype with pointer to GPIO structure, unsigned 32 integer argument, and boolean argument.
void OLED_initialize(void);																								// Function prototype with no arguments.
void OLED_sendByte(char character);																				// Function prototype with character arugment.
void OLED_sendCharacter(char chracter);																		// Function prototype with character argument.
void OLED_sendCommand(char character);																			// Function prototype with character argument.
void OLED_commandMode(void);																								// Function prototype with no arguments. 
void OLED_setWrite(void);																									// Function prototype with no arguments. 
void OLED_characterMode(void);																							// Function prototype with no arguments. 
void OLED_enable(void);																										// Function prototype with no arguments. 
void OLED_sendString(char * string);																				// Function prototype with string argument. 
void OLED_sendInt(int to_display);																				// Function prototype with floating point argument. to send floating point value to LCD.

int calculate_speed(uint16_t period, double numerator);										// Function prototype with unsigned 16 bit integer and double as its parameters.
int send_speed(int speed);																								// Function prototype with integer as its argument.  
uint16_t period = 0;				// Variable to store period between captures.
int revolution = 0;					// Variable to store number of input captures during runtime.
int refresh_rate = 4;				// Variable to control when LCD refreshes.
_Bool refresh_flag = 0;			// Variable to be used as a flag.

// Function to be called on input capture event. Will get period between input captures.
// Has no return type. 
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim -> Instance == TIM1)															// On input capture event:
	{
		if(revolution < refresh_rate)														// Increase number of revolutions until refresh rate has been reached.
			revolution++;
		if(revolution == refresh_rate + 1 && refresh_flag == 1)	// Set refresh to a larger value once we start picking up speed. 
			refresh_rate = 8;
		
		period = __HAL_TIM_GET_COMPARE(&htim1,TIM_CHANNEL_1);		// Get period of input captures.
		
		__HAL_TIM_SET_COUNTER(&htim1,0);												// Reset counter back to zero. 
	}
}

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */
	
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM1_Init();

  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

	OLED_initialize();		// Calling function to display initial information in conversion mode. 
	
	HAL_TIM_Base_Start(&htim2);									// Starting base timer. 
	HAL_TIM_IC_Start_IT(&htim1,TIM_CHANNEL_1);	// Starting input capture in interrupt mode.

	double numerator = 720 * 2.5 * 3.1459 ;			// Makes calculation for km/hr.
	
	_Bool zero_flag = 0;				// Variable to keep track of when to display zero speed.
	int speed_r = 0;						// Variable to store speed calculation value.
	uint16_t count_track = 0;		// Keeps track of counter when inactive. 
	
	while(1)	
  {
//		if(revolution > 0)																// Checking if a pulse has been detected from Hall effect sensor. UNEEDED IF statement. 
//		{
				count_track = __HAL_TIM_GET_COUNTER(&htim1);		// Get count time from counter.
				if(revolution == refresh_rate)									// Make speed calculation when refresh rate is reached.
				{ 
					speed_r = 0;																	// Set speed to zero to get rid of old value.
					speed_r = calculate_speed(period,numerator);	// Call function to calculate speed.
					send_speed(speed_r);													// Call function to send speed to OLED.
					period = 0;																		// Resetting variables.
					zero_flag = 1;
					revolution = 1;
					refresh_flag = 1;
					
				}
				else if(count_track > 12000 && zero_flag == 1)	// Checking if the timer is above 12000. This tells us the wheel is not moving.
				{
					int to_disp = 0;			// Set value to display to zero.
					send_speed(to_disp);	// Send zero speed to OLED.
					zero_flag = 0;				// Resetting variables.
					count_track =0;
					refresh_flag = 0;
					refresh_rate = 3;
				}			
			//}	
	}	
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* TIM1 init function */
static void MX_TIM1_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 4800;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 60000;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 15;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_SlaveConfigTypeDef sSlaveConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_DISABLE;
  sSlaveConfig.InputTrigger = TIM_TS_ITR3;
  if (HAL_TIM_SlaveConfigSynchronization(&htim2, &sSlaveConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, EN_Pin|D1_Pin|D2_Pin|LD3_Pin 
                          |LD6_Pin|LD4_TEST_Pin|LD5_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, R_S_Pin|R_W_Pin|E_Pin|Data_Bus_Pin 
                          |D0_Pin|D3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Data_BusB0_Pin|Data_BusB1_Pin|D5_Pin|D6_Pin 
                          |D7_Pin|D4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : EN_Pin D1_Pin D2_Pin */
  GPIO_InitStruct.Pin = EN_Pin|D1_Pin|D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : R_S_Pin R_W_Pin E_Pin Data_Bus_Pin 
                           D0_Pin D3_Pin */
  GPIO_InitStruct.Pin = R_S_Pin|R_W_Pin|E_Pin|Data_Bus_Pin 
                          |D0_Pin|D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Data_BusB0_Pin Data_BusB1_Pin D5_Pin D6_Pin 
                           D7_Pin D4_Pin */
  GPIO_InitStruct.Pin = Data_BusB0_Pin|Data_BusB1_Pin|D5_Pin|D6_Pin 
                          |D7_Pin|D4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD6_Pin LD4_TEST_Pin LD5_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD6_Pin|LD4_TEST_Pin|LD5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

}

/* USER CODE BEGIN 4 */

// Function will simply display the initial information when getting into conversion mode.
// Has no return type.
void OLED_initialize()
{
	OLED_sendCommand(0x1);				// Clear display.
	OLED_sendCommand(0x38);			// Set to 8-bit mode and 2 line dispaly.
	OLED_sendCommand(0x0E);			// Turn on display and cursor.
	OLED_sendCommand(0x06);			// Set cursor to first position.
	OLED_sendCommand(0x17);			// Set the mode to increment address by one. 
	OLED_sendCommand(0x80);			// Setting cursor position.
	OLED_sendString("Speed:");
}


// This function will use it's arguments to calculate the speed and return result. 
// Has integer return type.
int calculate_speed(uint16_t period,double numerator)
{	
	double speed = 0;								// Set speed to zero.
	if(period != 0)									// Making sure to not divide by zero.
		speed = numerator/(period);		// Calculating speed. 
	speed = (int) speed + .5;				// Typecasting from double to int. Adding by .5 for rounding.
	return speed;										// Return integer.
	
}

// This function will display the integer passed in to the OLED. 
int send_speed(int speed)
{
	OLED_sendCommand(0x1);			// Call function to clear display.
	OLED_sendCommand(0x80);		// Call function to set cursor position.
	OLED_sendString("Speed:");	// Call function to display string.
	OLED_sendCommand(0xC0);		// Call function to set cursor location.
	OLED_sendInt(speed);			// Call function to display speed.
	
	return 1;

}

// Function protoype to write to BRR register. Function arguments is pointer to GPIO port, a pin number to write to, 
// and a boolean value.
void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state)
{
		if(bit_state)										// Checks if outport pin needs to be activated.
		{
			port -> BSRR |=  pin_number;	// Set GPIO output pin logic level high.
		}
		else
			port -> BRR |= pin_number;		// Reset GPIO output port. 
		
}

// Function to write to all GPIO data pins for LCD. Function argument is a character to be written out. 
void OLED_sendByte(char character)
{
	send_bit(GPIOA,GPIO_PIN_9, character & 1);		  //  1 = 0b00000001. Write to Data Pin 0.
	send_bit(GPIOC,GPIO_PIN_4, character & 2);   		//  2 = 0b00000010. Write to Data Pin 1.
	send_bit(GPIOC,GPIO_PIN_5, character & 4);	  	//  4 = 0b00000100. Write to Data Pin 2.
	send_bit(GPIOA,GPIO_PIN_10, character & 8);	  	//  8 = 0b00001000. Write to Data Pin 3.
	send_bit(GPIOB,GPIO_PIN_12, character & 16);  	// 16 = 0b00010000. Write to Data Pin 4.
	send_bit(GPIOB,GPIO_PIN_2, character & 32);   	// 32 = 0b00100000. Write to Data Pin 5.
	send_bit(GPIOB,GPIO_PIN_10, character & 64); 		// 64 = 0b01000000. Write to Data Pin 6.
	send_bit(GPIOB,GPIO_PIN_11, character & 128);		//128 = 0b10000000. Write to Data Pin 7.
	
	HAL_Delay(5);																	// Wait for LCD to propegate commands. 
	// Disabling LCD
	send_bit(EN_GPIO_Port,EN_Pin, 0);								// Disable functionality.


}

// Function to select write mode.
void OLED_setWrite()
{
	send_bit(R_W_GPIO_Port,R_W_Pin,0);	// Set RW output to logic level low.
}

// Function to specify data register of LCD.
void OLED_characterMode()
{
	send_bit(R_S_GPIO_Port,R_S_Pin,1);
}

// Function to select instruction register.
void OLED_commandMode()
{
	send_bit(R_S_GPIO_Port,R_S_Pin,0);	// Set RS pin to logic level low.
}

// Function to enable LCD functionality.
void OLED_enable()
{
	HAL_Delay(5);										// Give delay to ensure LCD can accept input.
	// Enable
	send_bit(EN_GPIO_Port,EN_Pin, 1); //1 = 0b00000001. 
	
}

// Function to make necessary function calls and write character to LCD.
// Function argument is a character to be displayed.
void OLED_sendCharacter(char character)
{
	OLED_setWrite();
	OLED_characterMode();
	OLED_enable();
	OLED_sendByte(character);
	

}

// Function to send command to LCD. Function argument is a character which is the instruction. 
void OLED_sendCommand(char character)
{
	OLED_setWrite();						// Set LCD to write mode.
	OLED_commandMode();				// Set to write to instruction register.
	OLED_enable();							// Enable functionality.
	OLED_sendByte(character);	// Send characters to LCD.
	

}

// Function to send string to LCD. Takes in character datat type as argument.
void OLED_sendString(char * string)
{
	while(*string)	// Loop through entire string character by character.
	{
		OLED_sendCharacter(*string++);	// Send current character to LCD and post increment.
		
	}
}

// Function to send floating point value to LCD.
void OLED_sendInt(int to_display)
{
	char stringNumber[10];									// Initializing variable to store string. 
	sprintf(stringNumber,"%d", to_display);	// Converts floating point value to string. String stored in stringNumber.
	OLED_sendString(stringNumber);						// Write string to LCD.
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
