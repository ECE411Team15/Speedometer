/* Andrew Capatina 10/27/2017

*/

struct flags * flags_ptr {
	
	_Bool master_on_switch;
	
	
	
}; 