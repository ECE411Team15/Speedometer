/*
	12/4/2017
	Andrew Capatina
	Linyi Hong
	Zach Stamler
	Nathan Dusciuc

	This is a header file containing all function prototypes for our speed conversion program.
*/
																																					// **ALL FUNCTION ARGUMENTS PASSED BY VALUE**
void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state);	// Function prototype with pointer to GPIO structure, unsigned 32 integer argument, and boolean argument.
void OLED_initialize(void);																								// Function prototype with no arguments.
void OLED_sendByte(char character);																				// Function prototype with character arugment.
void OLED_sendCharacter(char chracter);																		// Function prototype with character argument.
void OLED_sendCommand(char character);																		// Function prototype with character argument.
void OLED_commandMode(void);																							// Function prototype with no arguments. 
void OLED_setWrite(void);																									// Function prototype with no arguments. 
void OLED_characterMode(void);																						// Function prototype with no arguments. 
void OLED_enable(void);																										// Function prototype with no arguments. 
void OLED_sendString(char * string);																			// Function prototype with string argument. 
void OLED_sendInt(int to_display);																				// Function prototype with floating point argument. to send floating point value to LCD.
void OLED_sendFloat(float FloatNumber);

void ButtonUp(char *ShowupList[10], int Location);
void ButtonDown(char *ShowupList[10], int Location);

														// **All function prototypes below have void return types with no function arguments.**
void ButtonMode(void);
void Flag_Check(void);
void ButtonSelect(void);
void ButtonLeft(void);
void ButtonRight(void);
void Mode_Check(void);
void UserButtonLeft(void);
void UserButtonRight(void);
void UnitUp(void);
void UnitDown(void);
void UserSettingMode(void);
void SpeedMode(void);

int calculate_speed(uint16_t period, double numerator);										// Function prototype with unsigned 16 bit integer and double as its parameters.
int send_speed(int speed);																								// Function prototype with integer as its argument.  