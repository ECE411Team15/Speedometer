/*
	12/4/2017
	Andrew Capatina
	Linyi Hong
	Zach Stamler
	Nathan Dusciuc

	This file includes all the functions used for our speed conversion program 
	along with variable declerations.
*/


#include "header.h"				// File which contains function prototypes.

extern TIM_HandleTypeDef htim1;	// Timer structure typedefs.
extern TIM_HandleTypeDef htim2;

uint8_t conversion_mode = 0;				// Variable to keep track of which mode we are currently in.
int Selectflag = 0;									// Flag for checking if the Select Button is clicked
int Modeflag = 0;										// Flag to show if the Mode have been changed and need to be checked
int Leftflag = 0;										// Flag that Left button is use for changing mode
int Rightflag = 0;									// Flag that Right button is use for changing mode
int Upflag = 0;											// Changing Parameter flag
int Downflag = 0;										// Changing Parameter flag
int ModeLeftflag = 0;								// Left button flag under User Setting Mode
int ModeRightflag = 0;							// Right button flag under User Setting Mode
int UnitOption = 0;									
int UnitUpflag = 0;									// Up button flag for Speed Mode to change units
int UnitDownflag = 0;								// Down button flag for Speed Mode to change units
int Position = 0;										// A pointer for detecting the parameter that current input
int Mode = 0;												// Mode: 1 is Speed Mode, 0 is User Setting Mode
int radius[4] = {0,0,0,0};					// Matrix for recording all the number for the radius
float Radius = 0;										// The real radius that use for calculation
int Place = 0;											// A pointer for detect which number that the user input now
char  *Option[10] = {"0","1","2","3","4","5","6","7","8","9"};

uint16_t period = 0;				// Variable to store period between captures.
int revolution = 0;					// Variable to store number of input captures during runtime.
int refresh_rate = 4;				// Variable to control when OLED refreshes.
_Bool refresh_flag = 0;			// Variable to be used as a flag.
_Bool zero_flag = 0;				// Variable to keep track of when to display zero speed.
_Bool	go_flag = 0;					// Variable used to prompt user when to begin moving. 
_Bool disp_update_flag_1;		// Variable used to know if speed is above 10.
_Bool disp_update_flag_2;		// Variable used to know if speed is above 100.
_Bool disp_update_flag_3;		// Variable used to know if speed is above 1000.

uint16_t timer_count = 0;			// Stores count from timer.
double numerator = 0;					// Stores result of numerator for speed calculation.
int speed = 1;								// Stores calculated speed result.
_Bool initial_clear = 0;			// Used for initially clearing the display in speed mode.
int zero_refresh = 1250;			// Variable that holds threshold for setting the speed to zero.
int previous_speed = 0;				// Value to hold previously calculated speed.


// The following function will switch between user setting mode and speed conversion mode. 
void Mode_Check()
{
	if(Modeflag){								// If the user has requested to change modes..
		switch(Mode){							// Evaluate value of Mode.
			case 0:{		
				UserSettingMode();		// Enter using settings mode.
				break;
			}
			case 1:{
				SpeedMode();					// Enter speed conversion mode.
				break;
			}
		}
	}
	Modeflag = 0;								// Reset flag.

}

/* The following function will react based upon the user input. 
   User input will be provided by the buttons connected to the 
   GPIO inputs. */
void Flag_Check(void)
{													// Left and Right buttons will be used to either switch modes
													// Or set the radius in user program. That's why they're being checked twice.
	
  if (Selectflag)					// Checking if select input by user has been given.
    ButtonSelect();				// Call function to confirm selection.
  if (Leftflag)						// Checking if user has selected left button.
    ButtonLeft();					// Call function to set modes for left.
  if (Rightflag)					// Checking if user has selected to navigate right.
    ButtonRight();				// Call function to set modes for right.
  if (ModeLeftflag)				// Checking if user has selected to navigate left.
    UserButtonLeft();			// Call function to navigate.
  if (ModeRightflag)			// Checking if user has selected to navigate right.
    UserButtonRight();		// Call function to navigate.
  if (Upflag)							// Checking if user wants to navigate up.
	{
		Position++;									// Increment position.
		if (Position > (10-1))			// Reset if out of bounds.
    Position = 0;							
    ButtonUp(Option, Position);	// Call function to show change to user.
	}
  if (Downflag)									// Checking if user wants to navigate down.
	{  
		Position--;									// Decrement position.
  if (Position < 0)							// Reset if out of bounds.
		Position = 10 - 1;
    ButtonDown(Option, Position);	// Call function to show change to user.
	}
  if (UnitUpflag)								// Checking if user wants to change units of conversion.
    UnitUp();										// Call function to set the mode change.
  if (UnitDownflag)							// Checking the same thing, allows user to use up and down for changing conversion mode.
    UnitDown();
}

void UserSettingMode()
{
		HAL_TIM_IC_Stop_IT(&htim1,TIM_CHANNEL_1);	// Stop input capture in interrupt mode.
		OLED_sendCommand(0x38);										// Set to 8-bit mode and 2 line dispaly.
		OLED_sendCommand(0x0E);										// Turn on display and cursor.
		OLED_sendCommand(0x1);										// Clear OLED.
    OLED_sendCommand(0x2);										// Return to home state of OLED.
		OLED_sendCommand(0x06);										//Set the mode to increment address by one.
		Radius = 0;
		Place = 0;
		memset(radius,0,sizeof(radius));	// Set array values to zero.
		OLED_sendString("Radius:");				// Display to user radius value to be set.
		OLED_sendCommand(0xC0);						
		OLED_sendString("00.00cm");				
		OLED_sendCommand(0xC0);
		OLED_sendCommand(0x0F);
}

/* Function used to alternate between the following modes:
	 Setting the radius, displaying kilometers per hour, and 
	 displaying milers per hour. */
void SpeedMode()
{
	go_flag = 1;					// Setting flag for prompting user.
	
	while(Mode == 1)
	{
		if(go_flag == 1 && UnitOption != 0)				// If statement used to prompt user on initial selection of speed mode.
		{
			HAL_TIM_IC_Start_IT(&htim1,TIM_CHANNEL_1);	// Starting input capture in interrupt mode.
			
			OLED_sendCommand(0x01);			// Clearing OLED.
			OLED_sendCommand(0x80);			// Setting cursor position.
			if(UnitOption == 0)					// Display appropriate speed units.
				OLED_sendString("km/h");
			else
				OLED_sendString("mph");
			
			HAL_Delay(1250);						// Give delay so user can see the option they have selected.				
			OLED_sendCommand(0x01);	
			OLED_sendCommand(0x80);			
			OLED_sendString("Go!");			// User may now begin to ride the bike.		
			go_flag = 0;
			initial_clear = 1;
		}	
		
		if(previous_speed >= 10)		// Checking what the value of the previous speed was.
			disp_update_flag_1 = 1;			// Set flag to logic high if condition true.
		else
			disp_update_flag_1 = 0;
		if(previous_speed > 100)		// Setting flag if speed is above 100.
			disp_update_flag_2 = 1;		
		else
			disp_update_flag_2 = 0;
		if(previous_speed > 1000)		// Setting flag if speed is above 1000.
			disp_update_flag_3 = 1;		
		else
			disp_update_flag_3 = 0;
		
		
		switch(UnitOption){
		case 0: {
	/* Unit1 Code Begin*/
		
			
			break;
			}
		
		case 1: {
	/* Unit2 Code Begin*/
		timer_count = __HAL_TIM_GET_COUNTER(&htim1); // Get count time from counter.	
			
		if(revolution == refresh_rate)
		{
			HAL_NVIC_DisableIRQ(EXTI2_3_IRQn);					// Turning off mode functionality while calculating speed. FOR SAFETY
			HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);					// Turning off mode functionality while calculating speed. FOR SAFETY

			if(initial_clear == 1)											// If statement is used to clear "Go!" for initial use.
			{	
				OLED_sendCommand(0x1);										// Clearing OLED.
				initial_clear = 0;												// Reset flag.
			}
			
			numerator = 72 * Radius * 3.1459;
			
			speed = 0;																		// Set speed to zero to reset value.
			speed = calculate_speed(period,numerator);		// Call function to calculate speed.
			previous_speed = speed;												// Setting speed to variable to keep track of previous speed.
			send_speed(speed);														// Call function to send speed to OLED.
			OLED_sendCommand(0xC0);												// Setting cursor position.
			OLED_sendString("km/h");											// Speed unit to be calculated.
		

			period = 0;																		// Resetting variables.
			zero_flag = 1;																
			revolution = 1;
			go_flag = 0;																		
		}	
		else if(timer_count > zero_refresh && zero_flag == 1)
		{
			
			OLED_sendCommand(0x1);					// Clearing OLED.
			int to_disp = 0;								// Set value to display to zero.
			send_speed(to_disp);						// Send zero speed to OLED.
			OLED_sendCommand(0xC0);					// Setting cursor position to second line.
			if(conversion_mode == 1)				// Display the correct speed unit.
				OLED_sendString("km/h");
			else
				OLED_sendString("mph");
			
			HAL_NVIC_EnableIRQ(EXTI2_3_IRQn);		// Enable interrupts. Allows user to begin changing modes ONCE STOPPED.
			HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);	
			
			zero_flag = 0;					// Resetting variables.
			timer_count =0;
			refresh_flag = 0;
			speed = 0;
				
		}
			
			break;
			}
		case 2: {
			if(revolution == refresh_rate)
		{
			HAL_NVIC_DisableIRQ(EXTI2_3_IRQn);						// Turning off mode functionality while calculating speed. FOR SAFETY
			HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);						// Turning off mode functionality while calculating speed. FOR SAFETY

			if(initial_clear == 1)												// If statement is used to clear "Go!" for initial use.
			{
				OLED_sendCommand(0x1);											// Clearing OLED.
				initial_clear = 0;													// Reset flag.
			}
			numerator = 72 * Radius * 3.1459*.621371;
			speed = 0;																		// Set speed to zero to reset value.
			speed = calculate_speed(period,numerator);		// Call function to calculate speed.
			previous_speed = speed;												// Setting speed to variable to keep track of previous speed.
			send_speed(speed);														// Call function to send speed to OLED.
			
			
			OLED_sendCommand(0xC0);												// Setting cursor position.
			OLED_sendString("mph");
			
			period = 0;																		// Resetting variables.
			zero_flag = 1;
			revolution = 1;		
			go_flag = 0;
		}
		else if(timer_count > zero_refresh && zero_flag == 1)
		{
			
			OLED_sendCommand(0x1);					// Clearing OLED.
			int to_disp = 0;								// Set value to display to zero.
			send_speed(to_disp);						// Send zero speed to OLED.
			OLED_sendCommand(0xC0);					// Setting cursor position to second line.
			if(conversion_mode == 1)				// Display the correct speed unit.
				OLED_sendString("km/h");
			else
				OLED_sendString("mph");
			
			HAL_NVIC_EnableIRQ(EXTI2_3_IRQn);		// Enable interrupts. Allows user to begin changing modes ONCE STOPPED.
			HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);	
			
			zero_flag = 0;					// Resetting variables.
			timer_count =0;
			refresh_flag = 0;
			speed = 0;
				
		}
			
		}
			}
		if(Radius > 20)					// If the radius is greater than 20 cm, update threshold for setting speed to zero.
			zero_refresh = 2000;
		else
			zero_refresh = 1250;
				
		}
		
}



/* Function called when the select button is pressed.*/
void ButtonSelect()
{
	radius[Place] = Position;			// Storing value entered at each index.
  Radius = radius[0]*10 + radius[1]*1 + radius[2]*0.1 + radius[3]*0.01;	// Get radius user has entered.
  Mode = 1;											
  Modeflag = 1;
  Selectflag = 0;                         //Reset the Selectflag.
}

/* Function for when the Leftflag highlight. */
void ButtonLeft()
{
	Mode--;
  if (Mode < 0)
		Mode = 1;
	Modeflag = 1;
  Leftflag = 0;                           //Reset the Leftflag.
}

void UserButtonLeft()
{
  radius[Place] = Position;		// Set array index to position on screen.
  Place--;						
  Position = 0;								
  if (Place < 0)							
  { 
    Place = 3; 
    OLED_sendCommand(0xC4);         //Move the cursor to the rightest side.
    OLED_sendCommand(0x0F);					//Blinking the Cursor.
  }
	else if (Place == 1)
  {
    OLED_sendCommand(0x10);					//Move the cursor to the left.
    OLED_sendCommand(0x10);					//Move the cursor to the left.
		OLED_sendCommand(0x0F);
  }
  else
  {
    OLED_sendCommand(0x10);					//Move the cursor to the left.
	  OLED_sendCommand(0x0F);					//Blinking the Cursor.
  }
	ModeLeftflag = 0;									// Reset flag.
}

/* Function for every time the Right button press */
void ButtonRight()
{  
  Mode++;						
  if (Mode>1)
  Mode = 0;
	Modeflag = 1;
  Rightflag = 0;                           //Reset the Rightflag.
}

void UserButtonRight()
{
  radius[Place] = Position;								// Set place holder to current position selected.  
  Place++;																// Increment current place holder.
  Position = 0;
  if (Place > (4 - 1))
  { 
    Place = 0;      
    OLED_sendCommand(0xC0);          			//Move the cursor to the rightest side.
    OLED_sendCommand(0x0F);					    	//Blinking the Cursor.
  }
  else if (Place == 2)
  {
    OLED_sendCommand(0x14);						  	//Move the cursor to the right.
    OLED_sendCommand(0x14);						  	//Move the cursor to the right.
	  OLED_sendCommand(0x0F);							  //Blinking the Cursor.		
  }
  else
  {
    OLED_sendCommand(0x14);						  	//Move the cursor to the right.
	  OLED_sendCommand(0x0F);							  //Blinking the Cursor.
  }
  ModeRightflag = 0;
}

/* Function for every time the Up button press*/
void ButtonUp(char *ShowupList[10], int Location)
{
	OLED_sendCharacter(*ShowupList[Location]);  // Show the context on the OLED.
	OLED_sendCommand(0x10);						        	// Move the DDRAM back to current position.
	OLED_sendCommand(0x0F);						        	// Blinking the Cursor.
  Upflag = 0;                                	// Reset the Upflag.
}

// Function to handle down button presses.
void UnitUp()
{
  UnitOption++;				// Increment user choice until reset is needed.
  if(UnitOption > 2)	
    UnitOption = 0;
  Modeflag = 1;
  UnitUpflag = 0;
}

/* Function for every time the Down button press*/
void ButtonDown(char *ShowupList[10], int Location)
{
	OLED_sendCharacter(*ShowupList[Location]);    //Show the context on the OLED.
	OLED_sendCommand(0x10);							        	//Move the DDRAM back to current position.						
	OLED_sendCommand(0x0F);							        	//Blinking the Cursor.
  Downflag = 0;                                 //Reset the Downflag.
}

// Function to 
void UnitDown()
{
  UnitOption--;
  if(UnitOption < 0)
    UnitOption = 2;
  Modeflag = 1;
  UnitDownflag = 0;
}

// Function will simply display the initial information when starting the program.
// Has no return type.
void OLED_initialize()
{
	OLED_sendCommand(0x38);			// Set to 8-bit mode and 2 line dispaly.
	OLED_sendCommand(0x0E);			// Turn on display and cursor.
	OLED_sendCommand(0x1);			// Clear OLED.
	OLED_sendCommand(0x2);			// Return OLED to home.
	OLED_sendCommand(0x06);			// Set the mode to increment address by one.
	OLED_sendString("Radius:");	// Initial prompt for user. User needs to set the radius.
	OLED_sendCommand(0xC0);			// Set position, display initial radius value.							
	OLED_sendString("00.00cm");
	OLED_sendCommand(0xC0);
	OLED_sendCommand(0x0F);
}


// This function will use it's arguments to calculate the speed and return result. 
// Has integer return type.
int calculate_speed(uint16_t period,double numerator)
{	
	double speed = 0;								// Set speed to zero.
	if(period != 0)									// Making sure to not divide by zero.
		speed = numerator/(period);		// Calculating speed. 
	speed = (int) speed + .5;				// Typecasting from double to int. Adding by .5 for rounding.
	return speed;										// Return integer.
	
}

// This function will display the integer passed in to the OLED. 
int send_speed(int speed)
{
	if((speed < 10 && disp_update_flag_1 == 1) || (speed < 100 && disp_update_flag_2 == 1) || (speed < 1000 && disp_update_flag_3 == 1))
		OLED_sendCommand(0x01);	// Clear flag if condition is true. Used to have a smoother displaying experience.
	OLED_sendCommand(0x80);		// Call function to set cursor position.
	OLED_sendInt(speed);			// Call function to display speed.
	
	return 1;

}


// Function protoype to write to BRR register. Function arguments is pointer to GPIO port, a pin number to write to, 
// and a boolean value.
void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state)
{
		if(bit_state)										// Checks if outport pin needs to be activated.
		{
			port -> BSRR |=  pin_number;	// Set GPIO output pin logic level high.
		}
		else
			port -> BRR |= pin_number;		// Reset GPIO output port. 
		
}

// Function to write to all GPIO data pins for OLED. Function argument is a character to be written out. 
void OLED_sendByte(char character)
{
	send_bit(D0_GPIO_Port,D0_Pin, character & 1);		  //  1 = 0b00000001. Write to Data Pin 0.
	send_bit(D1_GPIO_Port,D1_Pin, character & 2);   	//  2 = 0b00000010. Write to Data Pin 1.
	send_bit(D2_GPIO_Port,D2_Pin, character & 4);	  	//  4 = 0b00000100. Write to Data Pin 2.
	send_bit(D3_GPIO_Port,D3_Pin, character & 8);	  	//  8 = 0b00001000. Write to Data Pin 3.
	send_bit(D4_GPIO_Port,D4_Pin, character & 16);  	// 16 = 0b00010000. Write to Data Pin 4.
	send_bit(D5_GPIO_Port,D5_Pin, character & 32);   	// 32 = 0b00100000. Write to Data Pin 5.
	send_bit(D6_GPIO_Port,D6_Pin, character & 64); 		// 64 = 0b01000000. Write to Data Pin 6.
	send_bit(D7_GPIO_Port,D7_Pin, character & 128);		//128 = 0b10000000. Write to Data Pin 7.
	
	HAL_Delay(5);																		// Wait for OLED to propegate commands. 
	// Disabling OLED
	send_bit(EN_GPIO_Port,EN_Pin, 0);								// Disable functionality.					// Disable functionality.


}

// Function to select write mode.
void OLED_setWrite()
{
	send_bit(RW_GPIO_Port,RW_Pin,0);	// Set RW output to logic level low.
}

// Function to specify data register of OLED.
void OLED_characterMode()
{
	send_bit(RS_GPIO_Port,RS_Pin,1);
}

// Function to select instruction register.
void OLED_commandMode()
{
	send_bit(RS_GPIO_Port,RS_Pin,0);	// Set RS pin to logic level low.
}

// Function to enable OLED functionality.
void OLED_enable()
{
	HAL_Delay(5);										// Give delay to ensure OLED can accept input.
	// Enable
	send_bit(EN_GPIO_Port,EN_Pin, 1); //1 = 0b00000001. 
	
}

// Function to make necessary function calls and write character to OLEDD.
// Function argument is a character to be displayed.
void OLED_sendCharacter(char character)
{
	OLED_setWrite();					// Turn on functionality to write to OLED. 
	OLED_characterMode();
	OLED_enable();
	OLED_sendByte(character);
	

}

// Function to send command to OLED. Function argument is a character which is the instruction. 
void OLED_sendCommand(char character)
{
	OLED_setWrite();						// Set OLED to write mode.
	OLED_commandMode();					// Set to write to instruction register.
	OLED_enable();							// Enable functionality.
	OLED_sendByte(character);		// Send characters to OLED.
	

}

// Function to send string to OLED. Takes in character datat type as argument.
void OLED_sendString(char * string)
{
	while(*string)	// Loop through entire string character by character.
	{
		OLED_sendCharacter(*string++);	// Send current character to OLED and post increment.
		
	}
}

void OLED_sendFloat(float FloatNumber)
{
	char OLEDFloatNumber[6];
	sprintf(OLEDFloatNumber, "%g", FloatNumber);
	OLED_sendString(OLEDFloatNumber);
}

// Function to send floating point value to OLED.
void OLED_sendInt(int to_display)
{
	char stringNumber[10];										// Initializing variable to store string. 
	sprintf(stringNumber,"%d", to_display);		// Converts floating point value to string. String stored in stringNumber.
	OLED_sendString(stringNumber);						// Write string to OLED.
}

