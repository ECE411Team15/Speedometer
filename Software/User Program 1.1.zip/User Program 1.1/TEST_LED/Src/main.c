/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
#define clear_display = 0x1					// Clears display
#define return_home = 0x2						// Returns display to home
#define shift_curs_left = 0x4				// Shifts cursor left
#define shift_curs_right = 0x6			// Shifts cursor right
#define shift_disp_right = 0x18			// Shifts display right
#define shift_disp_left = 0x7				// Shift display left
#define display_off = 0x8						// Turn off display
#define disp_on_curs_off = 0xC			// Turn on display, cursor off
#define disp_on_curs_on = 0xE				// Turn on display, cursor on
#define disp_on_blink = 0xF					// Turn on display, cursor blink
#define move_curs_left = 0x10				// Move cursor left
#define move_curs_right = 0x1C			// Move cursor right
#define curs_reset_first = 0x80			// Reset/force cursor to first line
#define curs_reset_second = 0xC0		// Reset/force cursor to second line

// ---------------------------------------------------------------
#define command_byte = 0x38					// COMMAND WORD FOR 8 BIT MODE
// ---------------------------------------------------------------

int Selectflag = 0;									
int Modeflag = 0;
int Leftflag = 0;
int Rightflag = 0;
int Upflag = 0;
int Downflag = 0;
int Position = 0;
int Mode = 0;
float Radius = 0;
int Place = 0;
char  *Option[10] = {"0","1","2","3","4","5","6","7","8","9"};

void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state);
void LCD_sendByte(char character);
void LCD_sendCharacter(char chracter);
void LCD_sendCommand(char character);
void LCD_sendInteger(int Integer);
void LCD_sendFloatingNumber(float FloatNumber);
void LCD_sendString(char *String);
void LCD_ReadData(char character);
int ButtonUp(char *ShowupList[10], int Location);
int ButtonDown(char *ShowupList[10], int Location);
int ReadRadius();

unsigned char LCD_readByte(unsigned char character);

void LCD_commandMode(void);
void LCD_setRead();
void LCD_setWrite(void);
void LCD_characterMode(void);
void LCD_enable(void);
void ButtonMode();
void Flag_Check();
void ButtonSelect();
void ButtonLeft();
void ButtonRight();
void Mode_Check();

//void EXTI4_15_IRQHandler(void);

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

	//
	
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();

  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  //		HAL_Delay(300);
//LCD Initialize
		LCD_sendCommand(0x38);		//Set to 8-bit mode and 2 line dispaly.
		LCD_sendCommand(0x0E);		//Turn on display and cursor.
		LCD_sendCommand(0x1);			//clear_display
    LCD_sendCommand(0x2);
		LCD_sendCommand(0x06);		//Set the mode to increment address by one.


		LCD_sendString("Radius:");
		LCD_sendCommand(0xC0);				//Set the cursor to the second line.
		LCD_sendString("00.00cm");
		LCD_sendCommand(0xC0);
		LCD_sendCommand(0x0F);
//		HAL_Delay(2000);
//		BottunSelect();
//		BottunDown(Option,Position);
//		HAL_Delay(2000);
//		Position = 3;
//		BottunSelect();
//		BottunDown(Option,Position);
//		HAL_Delay(2000);
//		LCD_sendInteger(Position);
		
//		HAL_GPIO_ReadPin(Up_GPIO_Port, Up_Pin);

	//LCD_sendCommand(0x08);
	//LCD_sendCommand(0x6);
	

	//LCD_sendByte(character);

	//	LCD_sendCharacter('H');
	//	LCD_sendCharacter('I');
	



while (1)
{  {
		Flag_Check();
		Mode_Check();
		}
//	  LCD_sendCommand(0x0F);
//		HAL_Delay(3000);
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
//	HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_9);



  /* USER CODE END 3 */

}
}

/** System Clock Configuration
*/


void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_SlaveConfigTypeDef sSlaveConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_DISABLE;
  sSlaveConfig.InputTrigger = TIM_TS_ITR3;
  if (HAL_TIM_SlaveConfigSynchronization(&htim2, &sSlaveConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, EN_Pin|D1_Pin|D2_Pin|LD3_Pin 
                          |LD6_Pin|LD4_TEST_Pin|LD5_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, R_S_Pin|R_W_Pin|D0_Pin|D3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, D5_Pin|D6_Pin|D7_Pin|D4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : EN_Pin D1_Pin D2_Pin */
  GPIO_InitStruct.Pin = EN_Pin|D1_Pin|D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : R_S_Pin R_W_Pin D0_Pin D3_Pin */
  GPIO_InitStruct.Pin = R_S_Pin|R_W_Pin|D0_Pin|D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : D5_Pin D6_Pin D7_Pin D4_Pin */
  GPIO_InitStruct.Pin = D5_Pin|D6_Pin|D7_Pin|D4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD6_Pin LD4_TEST_Pin LD5_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD6_Pin|LD4_TEST_Pin|LD5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : Up_Pin Down_Pin Select_Pin Left_Pin */
  GPIO_InitStruct.Pin = Up_Pin|Down_Pin|Select_Pin|Left_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : Right_Pin */
  GPIO_InitStruct.Pin = Right_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(Right_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

  HAL_NVIC_SetPriority(EXTI2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_3_IRQn);

  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

}

/* USER CODE BEGIN 4 */


/* Data Analysis


*/


//Check
void Mode_Check()
{
	if(Modeflag){
	switch(Mode){
		case 0:{		
		LCD_sendCommand(0x38);		//Set to 8-bit mode and 2 line dispaly.
		LCD_sendCommand(0x0E);		//Turn on display and cursor.
		LCD_sendCommand(0x1);			//clear_display
    LCD_sendCommand(0x2);
		LCD_sendCommand(0x06);		//Set the mode to increment address by one.
		Radius = 0;
		Place = 0;

		LCD_sendString("Radius:");
		LCD_sendCommand(0xC0);				//Set the cursor to the second line.
		LCD_sendString("00.00cm");
		LCD_sendCommand(0xC0);
		LCD_sendCommand(0x0F);
		break;
		}
		case 1: {
		LCD_sendCommand(0x1);			//clear_display
		LCD_sendCommand(0x80);				//Set the cursor to the second line.
		LCD_sendString("Radius:");
		LCD_sendCommand(0xC0);				//Set the cursor to the second line.
		LCD_sendFloatingNumber(Radius);
		LCD_sendCommand(0x0C);
		}
	}
	}
	Modeflag = 0;

}

void Flag_Check(void)
{
  if (Selectflag)
    ButtonSelect();
//  if (Modeflag)
 //   ButtonMode();
  if (Leftflag)
    ButtonLeft();
  if (Rightflag)
    ButtonRight();
  if (Upflag)
	{
		Position++;
		if (Position > (10-1))
    Position = 0;
    ButtonUp(Option, Position);
	}
  if (Downflag)
	{  
		Position--;
  if (Position < 0)
		Position = 10 - 1;
    ButtonDown(Option, Position);
	}
}

/* Function for every time the Select button press*/
void ButtonSelect()
{
  {
    switch(Place)
    {
			case 0: {
        Radius = Radius + 10 * Position;
        Place = Place + 1;
        break;
      }
      case 1: {
				Radius = Radius + 1 * Position;
        Place = Place + 1;
        break;
      }
			case 2: { 
        Place = Place + 1;
        break;
			}
      case 3: {
        Radius = Radius + 0.1 * Position;
        Place = Place + 1;
        break;
      }
      case 4: {
        Radius = Radius + 0.01 * Position;
        Place = 0;
        Mode = 1;
				Modeflag = 1;
      }
		}
	  LCD_sendCommand(0x14);						  	//Move the cursor to next position.
	  LCD_sendCommand(0x0F);							  //Blinking the Cursor.
    Position = 0;
	}
  Selectflag = 0;                         //Reset the Selectflag.
}

/* Function for when the Modeflag highlight. */
/*void ButtonMode()                         //Mode change
{
  Mode = Mode + 1;
  if (Mode == 2)
    Mode = 0;
  Modeflag = 0;                           //Reset the Modeflag.
}*/

/* Function for when the Leftflag highlight. */
void ButtonLeft()
{
	Mode--;
  if (Mode < 0)
  Mode = 1;
	Modeflag = 1;
/*  Point--;
  if (Point < 0)
  { 
    Point = width - 1;      
    LCD_sendCommand(0x87+width);          //Move the cursor to the rightest side.
    LCD_sendCommand(0x0F);					    	//Blinking the Cursor.
  }
  else
  {
    LCD_sendCommand(0x10);						  	//Move the cursor to the left.
	  LCD_sendCommand(0x0F);							  //Blinking the Cursor.
  }
*/

  Leftflag = 0;                           //Reset the Leftflag.
}

/* Function for every time the Right button press*/
void ButtonRight()
{  
  Mode++;
  if (Mode>1)
  Mode = 0;
	Modeflag = 1;
/*
  Point++;
  if (Point > 3)
  { 
    Point = 0;      
    LCD_sendCommand(0x87);                //Move the cursor to the rightest side.
    LCD_sendCommand(0x0F);					    	//Blinking the Cursor.
  }
  else
  {
    LCD_sendCommand(0x14);						  	//Move the cursor to the left.
	  LCD_sendCommand(0x0F);							  //Blinking the Cursor.
  }
*/

  Rightflag = 0;                           //Reset the Rightflag.
}

/* Function for every time the Up button press*/
int ButtonUp(char *ShowupList[10], int Location)
{
	LCD_sendCharacter(*ShowupList[Location]);  //Show the context on the LCD.
	LCD_sendCommand(0x10);						        //Move the DDRAM back to current position.
	LCD_sendCommand(0x0F);						        //Blinking the Cursor.
  Upflag = 0;                                //Reset the Upflag.
}

/* Function for every time the Down button press*/
int ButtonDown(char *ShowupList[10], int Location)
{
	LCD_sendCharacter(*ShowupList[Location]);    //Show the context on the LCD.
	LCD_sendCommand(0x10);							        //Move the DDRAM back to current position.						
	LCD_sendCommand(0x0F);							        //Blinking the Cursor.
  Downflag = 0;                                   //Reset the Downflag.
}

void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state)
{
		if(bit_state)
		{
			port -> BSRR |=  pin_number;
		}
		else
			port -> BRR |= pin_number;
		
}

void LCD_sendByte(char character)
{

	send_bit(D0_GPIO_Port,D0_Pin, character & 1);		  //  1 = 0b00000001
	send_bit(D1_GPIO_Port,D1_Pin, character & 2);     //  2 = 0b00000010
	send_bit(D2_GPIO_Port,D2_Pin, character & 4);	  	//  4 = 0b00000100
	send_bit(D3_GPIO_Port,D3_Pin, character & 8);	  	//  8 = 0b00001000
	send_bit(D4_GPIO_Port,D4_Pin, character & 16);  	// 16 = 0b00010000
	send_bit(D5_GPIO_Port,D5_Pin, character & 32);   	// 32 = 0b00100000
	send_bit(D6_GPIO_Port,D6_Pin, character & 64); 		// 64 = 0b01000000
	send_bit(D7_GPIO_Port,D7_Pin, character & 128);		//128 = 0b10000000
	
	HAL_Delay(1);
	// Disabling LCD
	send_bit(EN_GPIO_Port,EN_Pin, 0);
}



void LCD_commandMode()
{
	send_bit(R_S_GPIO_Port,R_S_Pin,0);
}

void LCD_characterMode()
{
	send_bit(R_S_GPIO_Port,R_S_Pin,1);
}

void LCD_setWrite()
{
	send_bit(R_W_GPIO_Port,R_W_Pin,0);
}

/*void LCD_setRead()
{
  send_bit(R_W_GPIO_Port,R_S_Pin,1);
}*/

void LCD_enable()
{
	HAL_Delay(1);
	send_bit(EN_GPIO_Port,EN_Pin, 1); //1 = 0b00000001
	
}

void LCD_sendCharacter(char character)
{
	LCD_setWrite();
	LCD_characterMode();
	LCD_enable();
	LCD_sendByte(character);

}

void LCD_sendCommand(char character)
{
	LCD_setWrite();
	LCD_commandMode();
	LCD_enable();
	LCD_sendByte(character);
}

void LCD_sendString(char * String)
{
	while(*String)
  {
		LCD_sendCharacter(*String++);	
	}
}

/* Need to Change, read the data from the pin and store it in an array, also need delay between the byte read */
/*void LCD_ReadData(char character)
{
  LCD_characterMode();
  LCD_setRead();
  LCD_enable();
  delay;
  LCD_readByte(character);
}*/

/*
unsigned char LCD_readByte(unsigned char character)
{

}
*/
void LCD_sendInteger(int Integer)
{
	char LCD_Integer[6];
	sprintf(LCD_Integer, "%d", Integer);
	LCD_sendString(LCD_Integer);
}

void LCD_sendFloatingNumber(float FloatNumber)
{
	char LCDFloatNumber[6];
	sprintf(LCDFloatNumber, "%g", FloatNumber);
	LCD_sendString(LCDFloatNumber);
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
