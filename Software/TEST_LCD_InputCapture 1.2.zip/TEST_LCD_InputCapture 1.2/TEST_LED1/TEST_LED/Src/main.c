/*
	Andrew Capatina
	Linyi Hong
	Nathan Dusciuc
	Zach Stamler
	11/14/2017
	
	Used tutorials:
	NewbieHack:
	https://www.youtube.com/watch?v=micDbBN9s9k&list=PL6PplMTH29SHbfyqpSqn-2gyJZtuwzEqs
	
	Le Tan Phuc:
	https://letanphuc.net/2015/06/stm32f0-timer-tutorial-and-counter-tutorial/
	



*/

/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2017 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
			
	
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim1;		// TIM1 handle.
TIM_HandleTypeDef htim2;		// TIM2 handle.

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM1_Init(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
#define clear_display = 0x1					// Clears display.
#define return_home = 0x2						// Returns display to home.
#define shift_curs_left = 0x4				// Shifts cursor left.
#define shift_curs_right = 0x6			// Shifts cursor right.
#define shift_disp_right = 0x5			// Shifts display right.
#define shift_disp_left = 0x7				// Shift display left.
#define display_off = 0x8						// Turn off display.
#define disp_on_curs_off = 0xC			// Turn on display, cursor off.
#define disp_on_curs_on = 0xE				// Turn on display, cursor on.
#define disp_on_blink = 0xF					// Turn on display, cursor blink.
#define move_curs_left = 0x10				// Move cursor left.
#define move_curs_right = 0x1C			// Move cursor right.
#define curs_reset_first = 0x80			// Reset/force cursor to first line.
#define curs_reset_second = 0xC0		// Reset/force cursor to second line.

// ---------------------------------------------------------------
#define command_byte = 0x38					// COMMAND WORD FOR 8 BIT MODE
// ---------------------------------------------------------------

int input_capture;
_Bool flag; 
int mode = 0;
int i = 0;
float count = 0;
_Bool restart_flag = 0;

void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state);	// Function prototype with pointer to 
void LCD_sendByte(char character);																				// Function prototype with character arugment.
void LCD_sendCharacter(char chracter);																		// Function prototype with character argument.
void LCD_sendCommand(char character);																			// Function prototype with character argument.

void LCD_commandMode(void);																								// Function prototype with no arguments. 
void LCD_setWrite(void);																									// Function prototype with no arguments. 
void LCD_characterMode(void);																							// Function prototype with no arguments. 
void LCD_enable(void);																										// Function prototype with no arguments. 
void LCD_sendString(char * string);																				// Function prototype with string argument. 
void LCD_sendFloat(float to_display);																			// Function prototype with floating point argument. to send floating point value to LCD.


// Function to be called by interrupt event when capture event occurs.
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim -> Instance == TIM1)	// If event is from hall effect sensor
	{
		i = i + 1;																						// Increment value for LCD refresh.
		count = __HAL_TIM_GET_COMPARE(&htim1,TIM_CHANNEL_1);	// Compare input capture times.
		__HAL_TIM_SET_COUNTER(&htim1,0);											// Set counter back to zero once event occurs.
		
	}
	
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
		if(htim -> Instance == TIM3)
		{
			HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_8);
		}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == GPIO_PIN_0)
	{
		if(mode ==0)
			mode = 1;
		else 
		{
			mode = 0;
			//HAL_TIM_IC_Stop_IT(&htim1,TIM_CHANNEL_1);
		}
	}
}

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */
	_Bool sensor_flag;
	uint32_t rmw_var;
	int to_average = 0;

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

	//
	
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM1_Init();

  /* USER CODE BEGIN 2 */
	//float count;
	float speed = 0;
	_Bool m_flag = 0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  //		HAL_Delay(300);
	float val = 40.16349;
		LCD_sendCommand(0x1);			//clear_display
		LCD_sendCommand(0x38);		//Set to 8-bit mode and 2 line dispaly.
		LCD_sendCommand(0x0E);		//Turn on display and cursor.
		LCD_sendCommand(0x06);		//Set the mode to increment address by one.
		LCD_sendCommand(0x80);
		LCD_sendString("Speed:");
		LCD_sendCommand(0xC0);
		

    HAL_TIM_Base_Start(&htim2);
		HAL_TIM_IC_Start_IT(&htim1,TIM_CHANNEL_1);
	
	while(1)	
  {
		//if(restart_flag == 0)
		
		//m_flag = HAL_GPIO_ReadPin(GPIOA,GPIO_PIN_8);
		if(mode == 0)
		{
			//count = __HAL_TIM_GET_COUNTER(&htim1);
			//count = __HAL_TIM_GET_COMPARE(&htim1,TIM_CHANNEL_1);
			to_average = to_average + count;
			if(i == 5)
			{ 
				speed = (to_average/5);
				LCD_sendCommand(0x1);			//clear_display
				LCD_sendCommand(0xC1);
				LCD_sendCharacter(0x3E);
				LCD_sendCharacter(0x3E);
				LCD_sendFloat(count);
				i = 0;
				to_average = 0;
			}
			//if(count > 600)
			//	__HAL_TIM_SET_COUNTER(&htim1,0);
			
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	}
}

  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* TIM1 init function */
static void MX_TIM1_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_IC_InitTypeDef sConfigIC;

  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 48000;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 1000;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 4;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  if (HAL_TIM_IC_Init(&htim1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 4;
  if (HAL_TIM_IC_ConfigChannel(&htim1, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_SlaveConfigTypeDef sSlaveConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 100000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_DISABLE;
  sSlaveConfig.InputTrigger = TIM_TS_ITR3;
  if (HAL_TIM_SlaveConfigSynchronization(&htim2, &sSlaveConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, EN_Pin|D1_Pin|D2_Pin|LD3_Pin 
                          |LD6_Pin|LD4_TEST_Pin|LD5_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, R_S_Pin|R_W_Pin|E_Pin|Data_Bus_Pin 
                          |D0_Pin|D3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, Data_BusB0_Pin|Data_BusB1_Pin|D5_Pin|D6_Pin 
                          |D7_Pin|D4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : EN_Pin D1_Pin D2_Pin */
  GPIO_InitStruct.Pin = EN_Pin|D1_Pin|D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : R_S_Pin R_W_Pin E_Pin Data_Bus_Pin 
                           D0_Pin D3_Pin */
  GPIO_InitStruct.Pin = R_S_Pin|R_W_Pin|E_Pin|Data_Bus_Pin 
                          |D0_Pin|D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Data_BusB0_Pin Data_BusB1_Pin D5_Pin D6_Pin 
                           D7_Pin D4_Pin */
  GPIO_InitStruct.Pin = Data_BusB0_Pin|Data_BusB1_Pin|D5_Pin|D6_Pin 
                          |D7_Pin|D4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD6_Pin LD4_TEST_Pin LD5_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD6_Pin|LD4_TEST_Pin|LD5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

}

/* USER CODE BEGIN 4 */

// Function protoype to write to BRR register. Function arguments is pointer to GPIO port, a pin number to write to, 
// and a boolean value.
void send_bit(GPIO_TypeDef *port, uint32_t pin_number, _Bool bit_state)
{
		if(bit_state)										// Checks if outport pin needs to be activated.
		{
			port -> BSRR |=  pin_number;	// Set GPIO output pin logic level high.
		}
		else
			port -> BRR |= pin_number;		// Reset GPIO output port. 
		
}

// Function to write to all GPIO data pins for LCD. Function argument is a character to be written out. 
void LCD_sendByte(char character)
{
	send_bit(GPIOA,GPIO_PIN_9, character & 1);		  //  1 = 0b00000001. Write to Data Pin 0.
	send_bit(GPIOC,GPIO_PIN_4, character & 2);   		//  2 = 0b00000010. Write to Data Pin 1.
	send_bit(GPIOC,GPIO_PIN_5, character & 4);	  	//  4 = 0b00000100. Write to Data Pin 2.
	send_bit(GPIOA,GPIO_PIN_10, character & 8);	  	//  8 = 0b00001000. Write to Data Pin 3.
	send_bit(GPIOB,GPIO_PIN_12, character & 16);  	// 16 = 0b00010000. Write to Data Pin 4.
	send_bit(GPIOB,GPIO_PIN_2, character & 32);   	// 32 = 0b00100000. Write to Data Pin 5.
	send_bit(GPIOB,GPIO_PIN_10, character & 64); 		// 64 = 0b01000000. Write to Data Pin 6.
	send_bit(GPIOB,GPIO_PIN_11, character & 128);		//128 = 0b10000000. Write to Data Pin 7.
	
	HAL_Delay(50);																	// Wait for LCD to propegate commands. 
	// Disabling LCD
	send_bit(EN_GPIO_Port,EN_Pin, 0);								// Disable functionality.


}

// Function to select instruction register.
void LCD_commandMode()
{
	send_bit(R_S_GPIO_Port,R_S_Pin,0);	// Set RS output to logic level low.
}

// Function to specify data register of LCD.
void LCD_characterMode()
{
	send_bit(R_S_GPIO_Port,R_S_Pin,1);
//	LCD_enable();
}

// Function to select instruction register.
void LCD_setWrite()
{
	send_bit(R_W_GPIO_Port,R_S_Pin,0);	// Set RS pin to logic level low.
}

// Function to enable LCD functionality.
void LCD_enable()
{
	HAL_Delay(50);										// Give delay to ensure LCD can accept input.
	// Enable
	send_bit(EN_GPIO_Port,EN_Pin, 1); //1 = 0b00000001. 
	
}

// Function to make necessary function calls and write character to LCD.
// Function argument is a character to be displayed.
void LCD_sendCharacter(char character)
{
	LCD_setWrite();
	LCD_characterMode();
	LCD_enable();
	LCD_sendByte(character);
	

}

// Function to send command to LCD. Function argument is a character which is the instruction. 
void LCD_sendCommand(char character)
{
	LCD_setWrite();						// Set LCD to write mode.
	LCD_commandMode();				// Set to write to instruction register.
	LCD_enable();							// Enable functionality.
	LCD_sendByte(character);	// Send characters to LCD.
	

}

// Function to send string to LCD. Takes in character datat type as argument.
void LCD_sendString(char * string)
{
	while(*string)	// Loop through entire string character by character.
	{
		LCD_sendCharacter(*string++);	// Send current character to LCD and post increment.
		
	}
}

// Function to send floating point value to LCD.
void LCD_sendFloat(float to_display)
{
	char stringNumber[10];									// Initializing variable to store string. 
	sprintf(stringNumber,"%g", to_display);	// Converts floating point value to string. String stored in stringNumber.
	LCD_sendString(stringNumber);						// Write string to LCD.
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
